Functions included in the project

BUTTONS THAT DOES NOT DEPEND ON SWITCHES 1 AND 0

1. Press on button 0 - full reset of screen + clearing memory.
2. Press on button 1 - increment by one. First 9 presses will result in output digits 1-9. Then 10th to 15th output will result in 'A' to 'F' character.
3. By pressing button 2 you will output on the screen number or charactered stored in a memory.

BUTTON THAT DEPENDS ON COMBINATION OF SWITCHES 

1. Both switches off and button 3 pressed - space (Blue color)
2. Switch 1 off and switch 0 on + button 3 presssed - move to next line (Green color)
3. Switch 1 on, switch 0 off and button 3 pressed - backspace (Blue color)
